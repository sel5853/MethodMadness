
public class dateStr 
{
	public static String dateStr(String dte)
	{
		return dte.substring(3, 5)+ "-" + dte.substring(0, 2) + "-" + dte.substring(6, 10);
		
	}
	
}
