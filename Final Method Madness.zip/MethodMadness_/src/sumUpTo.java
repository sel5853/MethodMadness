
public class sumUpTo 
{
	public static int sumUpTo(int x)
	{
		int total = 0;
		int b = 0;
		while (b <= x )
		{
			total = total + b;
			b++;
		}
		return total;
	}
	
	
}
