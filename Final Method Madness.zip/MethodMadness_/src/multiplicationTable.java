
public class multiplicationTable 
{
	
		
		
			   public static void multiplication(int base, int range)
			   {
			      for (int i = 0; i <= range; i++) 
			      {
			         System.out.print(i + ":");
			         
			         
			         System.out.print(i*base + " ");
			         
			         System.out.println();
			      }
			   } 
			
	

}
