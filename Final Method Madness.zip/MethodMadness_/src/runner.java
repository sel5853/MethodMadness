
public class runner 
{
	public static void main(String[] args) 
	{
		System.out.println(sumUpTo.sumUpTo(10));
		System.out.println(dateStr.dateStr("10/11/2017"));
		multiplicationTable.multiplication(5, 100);
	}
}
